import React, { Component } from 'react';
import UserLayout from "../HOC/UserLayout";

class index extends Component {
    render() {
        return (
            <UserLayout>
                
            </UserLayout>
        );
    }
}

export default index;