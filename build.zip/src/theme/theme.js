export default {
    palette: {
        primary: {
          light: '#08c',//'#33c9dc',
          main: '#08c', //'#00bcd4',
          dark:'#08c', //'#008394',
          contrastText: '#fff'
        },
        secondary: {
          light: '#ff6333',
          main: '#ff3d00',
          dark: '#b22a00',
          contrastText: '#fff'
        }
      },
      spreadIt: {

      }
    
}