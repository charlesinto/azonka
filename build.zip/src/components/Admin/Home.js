import React, { Component } from "react";
import Header from "../HeaderFooter/Header";
class Home extends Component{
    componentDidMount(){
        console.log('hello now o')
    }
    render(){
        return(
            <div>
                hi
            </div>
        )
    }
}

export default Home;