import React, { Component } from 'react';

class index extends Component {
    render() {
        return (
            <div className="not-found-page">
                The Page you are looking for does not exist
            </div>
        );
    }
}

export default index;