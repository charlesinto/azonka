export const endpoint = 'https://nyc3.digitaloceanspaces.com'
export const accessKeyId = 'NE2TNLXFZYKNNXMUB7F5'
export const secretAccessKey = 'RhFPj6bxYVKngJ+mjKCj6/NhxFeFREg7Sy71sn793o4' 
export const bucket = 'azonka'

export const PAY_STACK_TEST_KEY = 'sk_test_8ed095a4ef67cb0a8d6c3c540812dbe930d9764c'

export const countryApi = 'https://restcountries.eu/rest/v2/alpha/'